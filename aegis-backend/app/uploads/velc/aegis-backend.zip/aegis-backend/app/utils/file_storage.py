from __future__ import annotations

from pathlib import Path

from fastapi import UploadFile

from app.core.exceptions import FileStorageError, InvalidFileTypeError
from app.core.logging import logger

CHUNK_SIZE = 1024 * 1024  # 1 MB


def validate_zip_extension(filename: str | None) -> None:
    """
    Ensure the uploaded file has a `.zip` extension.

    Raises:
        InvalidFileTypeError: if `filename` is missing or not a `.zip`.
    """
    if not filename or not filename.lower().endswith(".zip"):
        raise InvalidFileTypeError(
            f"Invalid file '{filename}'. Only .zip files are accepted."
        )


async def save_upload(upload_file: UploadFile, destination_dir: Path) -> Path:
    """
    Persist an uploaded file to `destination_dir`, streaming it to disk
    in chunks to avoid loading large archives fully into memory.

    Args:
        upload_file: The incoming FastAPI `UploadFile`.
        destination_dir: Directory in which to store the file. Created
            if it does not already exist.

    Returns:
        The full path to the stored file.

    Raises:
        InvalidFileTypeError: if the filename is missing or not `.zip`.
        FileStorageError: if writing to disk fails.
    """
    validate_zip_extension(upload_file.filename)

    destination_dir.mkdir(parents=True, exist_ok=True)
    destination_path = destination_dir / upload_file.filename  # type: ignore[arg-type]

    try:
        with destination_path.open("wb") as buffer:
            while chunk := await upload_file.read(CHUNK_SIZE):
                buffer.write(chunk)
    except Exception as exc:  # noqa: BLE001
        logger.exception(f"Failed to store upload at {destination_path}")
        raise FileStorageError(str(exc)) from exc
    finally:
        await upload_file.close()

    logger.info(f"Stored upload: {destination_path}")
    return destination_path


def latest_payload(destination_dir: Path) -> Path | None:
    """
    Return the most recently modified `.zip` file in `destination_dir`,
    or `None` if no such file exists.

    Used by `/analyze` to verify that all required uploads have been
    provided before running the orchestrator.
    """
    if not destination_dir.exists():
        return None

    zip_files = sorted(
        destination_dir.glob("*.zip"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return zip_files[0] if zip_files else None
