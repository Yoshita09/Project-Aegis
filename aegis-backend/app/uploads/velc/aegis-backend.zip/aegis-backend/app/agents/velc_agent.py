from __future__ import annotations

from pathlib import Path

from app.agents.base import BaseAgent
from app.core.logging import logger
from app.schemas.agent_outputs import VelcOutput


class VelcAgent(BaseAgent[VelcOutput]):
    """
    VELC Agent (Vision Transformer).

    Analyzes VELC coronagraph payloads to detect pre-eruption signals,
    coronal loop expansion, and flux rope deformation risk.

    NOTE: Currently operates in mock mode. The `load()` method is a stub
    that should later load `agent_1(velc).pth` into a Vision Transformer
    via the inference wrapper in `app/services/inference.py`.
    """

    name = "velc"
    model_filename = "agent_1(velc).pth"

    def load(self) -> None:
        """
        Mock loader.

        Future implementation should:
          1. Resolve `self.model_dir / self.model_filename`.
          2. Load the Vision Transformer weights via torch.
          3. Set `self.model` to the loaded module in eval mode.
        """
        logger.info(f"[{self.name}] loading model (mock mode)")
        self.model = None
        self.loaded = True

    def predict(self, payload_path: Path) -> VelcOutput:
        """
        Run VELC inference on the uploaded coronagraph archive.

        Args:
            payload_path: Path to the stored VELC ZIP file.

        Returns:
            VelcOutput with mock metrics. Replace the body of
            `_infer()` with real Vision Transformer inference once
            `agent_1(velc).pth` is wired into `self.model`.
        """
        self._ensure_loaded()
        return self._run_safely(self._infer, payload_path)

    # ------------------------------------------------------------------
    def _infer(self, payload_path: Path) -> VelcOutput:
        logger.info(f"[{self.name}] running inference on {payload_path.name}")

        # --- MOCK INFERENCE -------------------------------------------------
        # TODO: Replace with real Vision Transformer forward pass using
        # `self.model` once `agent_1(velc).pth` is loaded.
        return VelcOutput(
            coronal_loop_expansion=0.94,
            flux_rope_deformation_risk=1.56,
            pre_eruption_signal_strength=4.51,
        )
