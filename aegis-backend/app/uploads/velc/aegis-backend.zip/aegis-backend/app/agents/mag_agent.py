from __future__ import annotations

from pathlib import Path

from app.agents.base import BaseAgent
from app.core.logging import logger
from app.schemas.agent_outputs import MagOutput


class MagAgent(BaseAgent[MagOutput]):
    """
    MAG Agent.

    Analyzes magnetic field telemetry to estimate magnetic stress and
    the probability of a magnetic reconnection event.

    NOTE: Currently operates in mock mode. The `load()` method is a stub
    that should later load `agent_3(magnetic).pth` via the inference
    wrapper in `app/services/inference.py`.
    """

    name = "mag"
    model_filename = "agent_3(magnetic).pth"

    def load(self) -> None:
        """
        Mock loader.

        Future implementation should load `agent_3(magnetic).pth` and
        assign the resulting model object to `self.model`.
        """
        logger.info(f"[{self.name}] loading model (mock mode)")
        self.model = None
        self.loaded = True

    def predict(self, payload_path: Path) -> MagOutput:
        """
        Run MAG inference on the uploaded magnetic field archive.

        Args:
            payload_path: Path to the stored MAG ZIP file.

        Returns:
            MagOutput with mock metrics. Replace `_infer()` with real
            inference once `agent_3(magnetic).pth` is wired into `self.model`.
        """
        self._ensure_loaded()
        return self._run_safely(self._infer, payload_path)

    # ------------------------------------------------------------------
    def _infer(self, payload_path: Path) -> MagOutput:
        logger.info(f"[{self.name}] running inference on {payload_path.name}")

        # --- MOCK INFERENCE -------------------------------------------------
        # TODO: Replace with real inference using `self.model`.
        return MagOutput(
            magnetic_stress=0.89,
            reconnection_probability=0.84,
        )
